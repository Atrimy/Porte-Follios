<?php
require 'Parametre/ParamsSession.php';
$test = 0;
require 'Parametre/params.php';

checkAuthentificationINDEX();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>RedClouds Corp. Log-In</title>
        <link rel="stylesheet" href="Style/style.css"/>
    </head>
    <body>
        <h1 class="titre">RedClouds Corp. Log-In</h1>
        <div class="fond2ndplan">
            <div class="stylediv">
                <form class='form_login' method="post" action="index.php" enctype="multipart/form-data">
                    <?php
                #<!-- DEFINITION DU Pseudo --># 
                        echo '<label class="labellogin" for="Pseudo">Pseudo : </label>';
                        getInput('Pseudo');
                        echo '<br />';

                #<!-- DEFINITION DU MDP --># 
                        echo '<label class="labellogin" for="MDP">Mot de passe : </label>';
                        echo '<input id="MDP" type="password" name="MDP" />';


                #<!-- TEST ERREUR --># 
                        if (empty($_POST) == false) 
                        {
                            $dsn            = 'mysql:host=localhost;dbname=utilisateurs;charset=utf8';
                            $USER_Pseudo    = 'root';
                            $USER_Password  = '';
                            
                            $sql = new PDO($dsn, $USER_Pseudo, $USER_Password);
                            
                            $resultat = $sql->query = ("SELECT personal_informations.Password "
                                ."FROM personal_informations"
                                ."WHERE personal_informations.Login like '".$_POST['Pseudo']."'"); 

                            while($data = $resultat->fetch()) 
                            { 
                                if ($_POST['Pseudo'] == '')
                                {
                                    echo '<center><p class="error">/!\ Pseudo non renseigné</p></center>';
                                }
                                if ($_POST['MDP'] == '')
                                {
                                    echo '<center><p class="error">/!\Mot de passe non renseigné</p></center>';
                                }
                                else if ($_POST['MDP'] != $data['Login_MDP'])
                                {
                                    echo '<center><p class="error">/!\ Mot de passe incorect</p></center>';
                                }

                                if ($_POST['MDP'] == $data['Login_MDP'])
                                {
                                    $_SESSION['isAuthenticated'] = TRUE;
                                    header('location: http://redclouds-corp.net/espace-admin/');
                                    exit;
                                }
                            } 
                        }
                        echo '<p><center><input class="arrondi" type= "image" id="Submit_LogIn" src="Images/Bouton_LogIn.gif"/></center></p>';
                        echo '</form>';
                    ?>
                </div>
            </div>
    </body>
</html>