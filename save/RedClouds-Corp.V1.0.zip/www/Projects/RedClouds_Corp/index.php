<html>
    <?php header ("location: ../../") ?>
</html>