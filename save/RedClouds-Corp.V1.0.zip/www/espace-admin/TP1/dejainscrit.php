<html>
    <head>
        <meta charset="UTF-8" />
        <title>Formulaire d'inscription</title>
        <link rel="stylesheet" href="style.css"/>
    </head>
    
    <body>
        <h1 class="titre">Formulaire d'inscription</h1>
        <br />
        <div class="merci">
        <?php
            echo '<center><div class="fond2ndplanmerci">Vous êtes déjà inscrit.</div></center>';
        ?>
        </div>