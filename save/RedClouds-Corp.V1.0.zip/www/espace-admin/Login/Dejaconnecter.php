<html>
    <head>
        <meta charset="UTF-8" />
        <title>Formulaire d'inscription</title>
        <link rel="stylesheet" href="Style/Merci.css"/>
    </head>
    
    <body>
        <h1 class="titre">Formulaire d'inscription</h1>
        <br />
        <div class="merci">
            <?php
                echo '<center><div class="fond2ndplanmerci">Vous êtes déjà connecté.';
                
                echo '<form method="post" action="page1.php" enctype="multipart/form-data">';
                  echo '<input type="submit" value="Retour "/>';
                echo '</form></div></center>';
            ?>
        </div>
    </body>
</html>