<?php
require 'Parametre/ParamsSession.php';
$test = 0;
require 'Parametre/params.php';

checkAuthentificationINDEX();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>RedClouds Corp. Log-In</title>
        <link rel="stylesheet" href="Style/style.css"/>
    </head>
    <body>
        <h1 class="titre">RedClouds Corp. Log-In</h1>
        <div class="fond2ndplan">
            <div class="stylediv">
                <form class='form_login' method="post" action="index.php" enctype="multipart/form-data">
                    <?php
                #<!-- DEFINITION DU Pseudo --># 
                        echo '<label class="labellogin" for="Pseudo">Pseudo : </label>';
                        getInput('Pseudo');
                        echo '<br />';

                #<!-- DEFINITION DU MDP --># 
                        echo '<label class="labellogin" for="MDP">Mot de passe : </label>';
                        echo '<input id="MDP" type="password" name="MDP" />';


                #<!-- TEST ERREUR --># 
                        if (empty($_POST) == false) 
                        {
                            $dsn            = 'mysql:dbname=Utilisateurs;host=127.0.0.1';
                            $USER_Pseudo    = 'root';
                            $USER_Password  = '';

                            $db = mysql_connect('localhost', 'root', ''); 

                            mysql_select_db('Utilisateurs',$db);
                            
                            $request = query(  "SELECT Personal_Informations.Password FROM Personal_Informations WHERE Personal_Informations.Login like :username",array("username" =>  $_POST['Pseudo']),$sql);
                            
                            while($data = mysql_query($request)) 
                            { 
                                if ($_POST['Pseudo'] == '')
                                {
                                    echo '<center><p class="error">/!\ Pseudo non renseigné</p></center>';
                                }
                                if ($_POST['MDP'] == '')
                                {
                                    echo '<center><p class="error">/!\Mot de passe non renseigné</p></center>';
                                }
                                else if ($_POST['MDP'] != $data['Login_MDP'])
                                {
                                    echo '<center><p class="error">/!\ Mot de passe incorect</p></center>';
                                }

                                if ($_POST['MDP'] == $data['Login_MDP'])
                                {
                                    $_SESSION['isAuthenticated'] = TRUE;
                                    header('location: page1.php');
                                    exit;
                                }
                            } 
                        }
                        echo '<p><center><input class="arrondi" type= "image" id="Submit_LogIn" src="Images/Bouton_LogIn.gif"/></center></p>';
                        echo '</form>';
                    ?>
                </div>
            </div>
    </body>
</html>