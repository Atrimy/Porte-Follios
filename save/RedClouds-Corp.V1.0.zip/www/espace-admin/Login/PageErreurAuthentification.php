<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Erreur d'athentification</title>
        <link rel="stylesheet" href="Style/Merci.css"/>
    </head>
    <body>
        <h1 class='titre'>Erreur d'athentification</h1>
        <div class="merci">
            <center>
                <div class="fond2ndplanmerci">
                    <?php
                        echo 'Merci de vous connecter pour accèder au contenu.';
                    ?>
                    <form method="post" action="index.php" enctype="multipart/form-data">
                        <input type="submit" value="Se Connecter"/>
                    </form>
                </div>
            </center>
        </div>
    </body>
</html>
