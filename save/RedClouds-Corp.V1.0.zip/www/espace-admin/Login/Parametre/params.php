<?php
function restore($pElement)
{
    //Test l'existance de la variable.
    if (isset($_POST[$pElement]) == true)
    {
        echo 'value="' . $_POST[$pElement] . '"';
    }
}

function getInput($pElementName)
{
    echo '<input id="' , $pElementName , '" type="' , $pElementName , '" name="' , $pElementName , '"';
    restore($pElementName);
    echo '/>';
}