<?php
    require 'Parametre/ParamsSession.php';
    checkAuthentification();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        echo 'CONNECTER !!';
        ?>
        <form method="post" action="deconnexion.php" enctype="multipart/form-data">
            <input type="submit" value="Deconnexion"/>
        </form>
    </body>
</html>
