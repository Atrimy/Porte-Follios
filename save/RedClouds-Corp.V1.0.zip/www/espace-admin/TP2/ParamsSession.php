<?php

session_start();

define('USER_LOGIN', 'Atrimy');
define('USER_SKYPE', 'atrimy');
define('USER_PWD', 'mot');


function checkAuthentification(){
        if (isset($_SESSION['isAuthenticated']) == FALSE){
        // Si non OK, alors rredirection vers la home.
            header("location:PageErreurAuthentification.php");
            exit;
        }
    }
    
function Connection ()
{

}
?>
