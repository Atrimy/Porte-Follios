<?php
    require 'ParamsSession.php';
    checkAuthentification();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Page 2</title>
        <link rel="stylesheet" href="style.css"/>
    </head>
    <body>
        <form method="post" action="page1.php" enctype="multipart/form-data">
            <input type="submit" value="Page 1"/>
        </form>
        <form method="post" action="deconnexion.php" enctype="multipart/form-data">
            <input type="submit" value="Deconnexion"/>
        </form>
        <?php
            $dsn            = 'mysql:dbname=ml_server;host=127.0.0.1';
            $USER_Pseudo    = 'root';
            $USER_Password  = '';
            $oDb = new PDO($dsn, $USER_Pseudo, $USER_Password);
            $oResultat = $oDb -> query('Select Staff_ID,Staff_Pseudo,Staff_Password From Staff');
            $oResultat->setFetchMode(PDO::FETCH_OBJ);

            while ($Login = $oResultat->fetch())
            {
                echo '<p>' , $Login->Staff_ID , ' -> ' , $Login->Staff_Pseudo , ' -> ' , $Login->Staff_Password , '</p>';
            }
        ?>
    </body>
</html>
