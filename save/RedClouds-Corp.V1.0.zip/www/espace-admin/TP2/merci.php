<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Merci</title>
        <link rel="stylesheet" href="Merci.css"/>
    </head>
    <body>
        <h1 class='titre'>Merci</h1>
        <center>
            <div class="merci">
                <?php
                    echo '<div class="fond2ndplanmerci">Merci de vous être inscrit.</div>';
                ?>
                <form method="post" action="index.php" enctype="multipart/form-data">
                    <input type="submit" value="Se connecter"/>
                </form>
            </div>
        </center>
    </body>
</html>
