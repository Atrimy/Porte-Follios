<?php
// Construit l'objet de base de données
$oDb = getDb();

// =============================================================================
// TRAITEMENT DU FORMULAIRE
// =============================================================================
// Vérifie si le formulaire a été envoyé (données reçues si POST n'est pas vide)
if (empty($_POST) == false) {
    // Teste si le prénom et le nom de l'étudiant ne sont pas vides
    if (empty($_POST['etu_prenom']) == false && empty($_POST['etu_nom']) == false) {

        // Prépare une requête qui attend des paramètres représentés par les ":"
        $oReq = $oDb->prepare('INSERT INTO etudiant (etu_prenom, etu_nom, promotion_id)'
                            . ' VALUES (:etu_prenom, :etu_nom, :promotion_id)');
        // Execute la requête en injectant les paramètres
        $oReq->execute(array(':etu_prenom'      => $_POST['etu_prenom'],
                             ':etu_nom'         => $_POST['etu_nom'],
                             ':promotion_id'    => $_GET['pro_id']));

        $okFormAjout = 'L\'étudiant a été enregistré';
    } else {
        $errorFormAjout = 'Veuillez saisir un prénom et un nom';
    }
}


// =============================================================================
// RECUPERATION DES DONNEES A AFFICHER
// =============================================================================
// Protège la donnée qui vient de l'extérieur (évite les injections SQL, hack...)
$pro_id = $oDb->quote($_GET['pro_id']);
// Lance une requête et récupère un jeu de résultats (tous les étudiants de la promotion_id = ?)
$oResultat = $oDb->query('SELECT * FROM etudiant WHERE promotion_id = ' . $pro_id . ' ORDER BY etu_nom, etu_prenom');

// Indique au jeu de résultats de retourner des objets
$oResultat->setFetchMode(PDO::FETCH_OBJ);

// Apelle la vue pour générer l'affichage
require '../views/view-promotion.php';
?>