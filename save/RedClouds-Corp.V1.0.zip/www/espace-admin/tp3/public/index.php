<?php
// Construit l'objet de base de données
$oDb = getDb();

// =============================================================================
// TRAITEMENT DU FORMULAIRE
// =============================================================================
// Vérifie si le formulaire a été envoyé (données reçues si POST n'est pas vide)
if (empty($_POST) == false) {
    // Teste si le nom de promotion n'est pas vide
    if (empty($_POST['pro_nom']) == false) {
        // Prépare une requête qui attend des paramètres représentés par les ":"
        $oReq = $oDb->prepare('INSERT INTO promotion (pro_nom) VALUES (:promotion_nom)');
        // Execute la requête en injectant les paramètres
        $oReq->execute(array(':promotion_nom' => $_POST['pro_nom']));

        $okFormAjout = 'La promotion a été enregistrée';
    } else {
        $errorFormAjout = 'Veuillez saisir un nom de promotion';
    }
}

// =============================================================================
// RECUPERATION DES DONNEES A AFFICHER
// =============================================================================
// Lance une requête et récupère un jeu de résultats (toutes les promotions)
$oResultat = $oDb->query('SELECT * FROM promotion ORDER BY pro_nom ASC');
// Indique au jeu de résultats de retourner des objets
$oResultat->setFetchMode(PDO::FETCH_OBJ);


// Appelle la vue pour générer l'affichage
require '../views/view-index.php';
?>
