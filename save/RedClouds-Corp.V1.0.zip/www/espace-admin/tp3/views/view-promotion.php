<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>IIA</title>
        <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
        <div>
            <?php
            if (isset($errorFormAjout) == true) {
                echo '<p class="error">' , $errorFormAjout , '</p>';
            }
            if (isset($okFormAjout) == true) {
                echo '<p class="success">' , $okFormAjout , '</p>';
            }
            ?>
            <form method="post" action="">
                Ajouter un étudiant (prénom nom) :
                <input type="text" name="etu_prenom" />
                <input type="text" name="etu_nom" />
                <input type="submit" value="OK" />
            </form>
        </div>

        <h1>Liste des étudiants</h1>
        <p><a href="index.php">Retour</a></p>
        <?php
        // Affiche le nombre de résultats retournés (nombre de promotions)
        echo '<p>Nombre d\'étudiants : ' , $oResultat->rowCount() , '</p>';

        // Affiche tous les étudiants par ordre alphabétique
        // Le fetch() retourne chaque ligne et false à la fin (ce qui permet de sortir du TANT QUE)
        while ($oEtudiant = $oResultat->fetch()) {
            // On récupère un résultat (sous forme d'un objet d'après la définition du setFetchMode)
            echo '<p>' , $oEtudiant->etu_nom  , ' ' , $oEtudiant->etu_prenom , '</p>';
        }
        ?>
    </body>
</html>