<!DOCTYPE html>
<?php
    //require '../library/params.php';
    // Se connecte à la base de donnée
    // /!\ ATTENTION : utiliser PDO et non mysql_connect(), mysql _query()...
    $oDb = My_Db::getDB();
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Gestion IIA</title>
        <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
        <div>
            <form method="post" action="">
                Ajouter un Etudiant (Prénom, Nom)

                <input type="text" name="Etu_nom" >
                <input type="text" name="Etu_pre" >
                <input type="submit" value="OK">
            </form>
        </div>
        
        <h1>Liste des étudiants</h1>
        
        <a href="index.php">Retour</a>
        
        <?php
           
           // Protege la BDD des données qui viennent de l'extérieur en injections SQL, Hacks
           $Pro_ID = $oDb->quote($_GET['pro_id']);
          
        
        // Récupère toutes les promotions
        // Lance une requete et récupère un jeu de résultat (toutes les promotions)
           $oResultat = $oDb->query('SELECT * FROM etudiants WHERE Pro_ID=' . $Pro_ID. ' ORDER BY Etu_nom, Etu_pre');
          
        // Affiche le nombre de résultats retournés (Nombre de promotions)
           echo '<p>Nombre d\'etudiants : ', $oResultat->rowCount(), '</p>';
        
        // indique au jeu de résultat de retourner des objets
           $oResultat->setFetchMode(PDO::FETCH_OBJ);
         
           
            
           
//============================================================================
// TRAITEMENT DU FORMULAIRE
//============================================================================
        // Vérifie si le POST n'est pas vide (formulaire envoyé)
        if (empty($_POST)== false)
        {           
            //test si le nom et le prénom ne sont pas vides
            if (empty($_POST['Etu_pre'])== false && empty($_POST['Etu_nom'])== false)
            {                
                // INSERT INTO ...
                // Prépare une requète qui attend des paramètres représentés par les ":"
                $oReq = $oDb->prepare('INSERT INTO etudiants (Etu_pre,Etu_nom,Pro_id)' 
                                        .' VALUES (:prenom,:nom,:promotion)');
                // Execute la requète en injectant les paramètres
                $oReq->execute(array(':prenom'      => $_POST['Etu_pre'],
                                     ':nom'         => $_POST['Etu_nom'],
                                     ':promotion'   => $_GET['pro_id']
                                     )
                              );
           
                $OkFormAjoutPre ='L\'étudiant été ajouté avec succès';
            }
            else
            {
                $errorFormAjoutPre = 'Saisir le prenom et le nom de l\'etudiant à ajouter';
            }
            
        }
        // gestion de cas d'erreur'
           if (isset($errorFormAjoutPre)== true)
            {
                echo '<p class="error">'.$errorFormAjoutPre. '</p>';
            }
            if (isset($OkFormAjoutPre)== true)
            {
                echo '<p class="succes">'.$OkFormAjoutPre. '</p>';
            }
            
            
        // Afficher toutes les etudiants par ordre alphabétique
        // Le fetch retourne chaque ligne et false à la fin (ce qui permet de sortir du Tant que)
           while ($oEtudiant = $oResultat -> fetch())
           {
               // on récupère le résultat sous forme d"un objet d'après la définition du fetchmode
               echo '<p><b>', $oEtudiant->Etu_nom , ' > ' , $oEtudiant->Etu_pre, '</b></p>';
           }
        
        
        ?>
    </body>
</html>
