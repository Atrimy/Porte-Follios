<?php
/**
 * Description of Promotion
 *=====================================
 * RECUPERATION DES DONNEES A AFFICHER 
 *===================================== 
 * @author Pierre
 */
class My_Entity_Promotion {
    Static Function getAll(){
        $oDb = My_Db::getDB();
        
        // Récupère toutes les promotions
        // Lance une requete et récupère un jeu de résultat (toutes les promotions)
        $oResultat = $oDb->query('SELECT * FROM promotion ORDER BY Pro_lib ASC');
        
        // indique au jeu de résultat de retourner des objets
        $oResultat->setFetchMode(PDO::FETCH_OBJ);
        return $oResultat;
    }
}
