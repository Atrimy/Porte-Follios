<?php

function __autoload($pClassName){
    echo 'Je suis autoload : '. $pClassName;
    
    $pClassName = str_repeat('_', '/', $pClassName);
    $pClassName = $pClassName + '.php';
    require '../Application/models ' . $pClassName;
}


$Controller = '../Application/Controller/'.$_GET['page'].'.php';
$View = '../Application/Views/'.$_GET['page'].'.php';

if (is_file($Controller)){
    //ouvre le fichier que lorsqu'il existe
    require $Controller;
    if (is_file($View)){
        //ouvre le fichier que lorsqu'il existe
        require $View;
    }
}