<?php

session_start();

$ftp = ftp_connect("webeducation3.lyceehautefollis.asso.fr", 2021) ;
ftp_login($ftp,  "education\Kevin.boutard" , "pepepirit");
//ftp_pasv($ftp, true);

$result = ftp_nlist($ftp, "CLASSES/1ASP1/" );


foreach($result as $file) {
    
    echo $file;
 echo '</br>'   ;
}






?>

