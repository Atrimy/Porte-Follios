<?php
$test = 0;
require 'params.php';
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8" />
        <title>Formulaire d'inscription</title>
        <link rel="stylesheet" href="style.css"/>
    </head>
    <body>
        <h1 class="titre">Formulaire d'inscription</h1>
        <form method="post" action="inscription.php" enctype="multipart/form-data">
        <?php
            $cheminstockage = "stockage/" . $_SERVER['REMOTE_ADDR'] . '/';
        ?>
            
        <div class="fond2ndplan">
<!-- DEFINITION DU Pseudo --> 
            <div class="stylediv">
                <label class="label" for="Pseudo">*Pseudo :       </label>
                <?php
                    getInput('Pseudo');
                    if (empty($_POST) == false) 
                    {
                        if ($_POST['Pseudo'] == '')
                        {
                            echo '<p class="error">/!\ Pseudo manquant</p>';
                            $test = 1;
                        }
                    }
                ?>
            </div>

                
<!-- DEFINITION DU PRENOM --> 
            <div class="stylediv">
                <label class="label" for="prenom">*Prénom :       </label>
                <?php
                    getInput('prenom');
                    if (empty($_POST) == false) 
                    {
                        if ($_POST['prenom'] == '')
                        {
                            echo '<p class="error">/!\ Prénom manquant</p>';
                            $test = 1;
                        }
                    }
                ?>
            </div>


<!-- DEFINITION DU NOM --> 
            <div class="stylediv">
                <label class="label" for="nom">*Nom :         </label>
                <?php
                    getInput('nom');
                    if (empty($_POST) == false) 
                    {
                        if ($_POST['nom'] == '')
                        {
                            echo '<p class="error">/!\ Nom manquant</p>';
                            $test = 1;
                        }
                    }
                ?>
            </div>


<!-- DEFINITION DE LA DATE DE NAISSANCE --> 
            <div class="stylediv">
                <label class="label">*Date de naissance :     </label>
                <select id="DDNJ" name="Jour">
                    <option></option>
                    <?php
                        foreach($aJour as $keyjour=>$aJour)
                        {
                            if(isset($_POST['Jour']) == true && $_POST['Jour'] == $keyjour)
                            {
                                echo'<option value="' , $keyjour , '" selected="selected">' , $aJour , '</option>';
                            }
                            else
                            {
                                echo'<option value="' , $keyjour , '">' , $aJour , '</option>';
                            }
                        }
                    ?>
                </select>
               /
               <select id="DDNM" name="Mois">
                    <option></option>
                    <?php
                        foreach($aMois as $keymois=>$aMois)
                        {
                            if(isset($_POST['Mois']) == true && $_POST['Mois'] == $keymois)
                            {
                                echo'<option value="' , $keymois , '" selected="selected">' , $aMois , '</option>';
                            }
                            else
                            {
                                echo'<option value="' , $keymois , '">' , $aMois , '</option>';
                            }
                        }
                    ?>
               </select>
               /
               <select id="DDNA" name="Annee">
                    <option></option>
                    <?php
                        foreach($aAnnee as $keyannee=>$aAnnee)
                        {
                            if(isset($_POST['Annee']) == true && $_POST['Annee'] == $keyannee)
                            {
                                echo'<option value="' , $keyannee , '" selected="selected">' , $aAnnee , '</option>';
                            }
                            else
                            {
                                echo'<option value="' , $keyannee , '">' , $aAnnee , '</option>';
                            }
                        }
                    ?>
              </select>
            <?php
                if (empty($_POST) == false) 
                {
                    if ($_POST['Jour'] == '' || $_POST['Mois'] == '' || $_POST['Annee'] == '')
                    {
                    echo '<p class="error">/!\ Date non-valide</p>';
                        $test = 1;
                    }
                }
            ?>
            </div>


<!-- DEFINITION DE LA CIVILITE --> 
            <div class="stylediv">
                <label class="label" for="Civilite">*Civilite : </label>
                <select id="Civilite" name="Civilite">
                    <option></option>
                    <?php
                        foreach($aCivilite as $keycivilite=>$aCivilite)
                        {
                            if(isset($_POST['Civilite']) == true && $_POST['Civilite'] == $keycivilite)
                            {
                                echo'<option value="' , $keycivilite , '" selected="selected">' , $aCivilite , '</option>';
                            }
                            else
                            {
                                echo'<option value="' , $keycivilite , '">' , $aCivilite , '</option>';
                            }
                        }
                    ?>
                </select>
                <?php
                    if (empty($_POST) == false) 
                    {
                        if ($_POST['Civilite'] == '')
                        {
                            echo '<p class="error">/!\ Civilité manquante</p>';
                            $test = 1;
                        }
                    }
                ?>
            </div>

<!-- DEFINITION D'UN AVATAR --> 
            <div class="stylediv">
               <label class="label" for="Avatar">Avatar :  </label>
               <input id="Avatar" type="file" name="Avatar" />
            </div> 

<!-- DEFINITION DE L'ADRESSE E-MAIL + COMFIRMATION --> 
            <div class="stylediv">
            <?php
                echo '<label class="label" for="email">*E-Mail : </label>';
                getInput('email');
                echo '<br /><br />';
                echo '<label class="label" for="emailconfirm">*E-Mail (confiramation) : </label>';
                getInput('emailconfirm');
                if (empty($_POST) == false) 
                {
                    if ($_POST['email'] == '')
                    {
                        echo '<p class="error">/!\ E-Mail manquant</p>';
                        $test = 1;
                    }
                    else if ($_POST['emailconfirm'] == '')
                    {
                        echo '<p class="error">/!\ E-mail non confirmé</p>';
                        $test = 1;
                    }
                    else if ($_POST['email'] != $_POST['emailconfirm'])
                    {
                        echo '<p class="error">/!\ E-Mail non-identiques</p>';
                        $test = 1;
                    }
                }
            ?>
            </div>


<!-- DEFINITION D'UN MOT DE PASSE + COMFIRMATION -->
            <div class="stylediv">
                <label class="label" for="MDP">*Mot de passe : </label>
                <input id="MDP" type="password" name="MDP" />
                <br />
                <br />
                <label class="label" for="MDPComfirm">*Mot de passe (comfirmation) : </label>
                <input id="MDPComfirm" type="password" name="MDPComfirm" />
            <?php
                if (empty($_POST) == false) 
                {
                    if ($_POST['MDP'] == '')
                    {
                        echo '<p class="error">/!\ Mot de passe manquant</p>';
                        $test = 1;
                    }
                    else if ($_POST['MDPComfirm'] == '')
                    {
                        echo '<p class="error">/!\ Mot de passe non confirmé</p>';
                        $test = 1;
                    }
                    else if ($_POST['MDP'] != $_POST['MDPComfirm'])
                    {
                        echo '<p class="error">/!\ Mots de passe non identiques</p>';
                        $test = 1;
                    }
                }
                ?>
            </div>
            <?php
                if ($test == 1)
                {
                    echo '<div class="error">Merci de remplir tout les champs obligatoires, signalés par une étoile. (*)</div>';
                }
                else
                {
                    if (empty($_POST) == false) 
                    {
                        mkdir($cheminstockage);
                        $date = date ('d/m/Y H:i:s');
                        
                        
                        $FichierSave = fopen($cheminstockage . 'Information.txt', 'w');
                        fwrite($FichierSave, 'Date et heure :     '  . $date                     . PHP_EOL);
                        fwrite($FichierSave, 'Pseudo :            '  . $_POST['Pseudo']          . PHP_EOL);
                        fwrite($FichierSave, 'E-Mail :            '  . $_POST['email']           . PHP_EOL);
                        fwrite($FichierSave, 'Mot de Passe :      '  . $_POST['MDP']             . PHP_EOL);
                        fwrite($FichierSave, 'Civilité :          '  . $_POST['Civilite']        . PHP_EOL);
                        fclose($FichierSave);
                        
                        $chemintmp      = $_FILES['Avatar']['tmp_name'];
                        $cheminNouveau  = $cheminstockage . $_FILES['Avatar']['name'];
                        move_uploaded_file($chemintmp, $cheminNouveau);
                        
                        header('Location: merci.php');
                        exit;
                    }
                }
                if(is_dir($cheminstockage) == true)
                {
                    header('Location: dejainscrit.php');
                    exit;
                }
            ?>
            <div class="stylediv">
               <input type="submit" value="Comfirmer l'inscription"/>
            </div>
        </div>
        </form>
    </body>
</html>