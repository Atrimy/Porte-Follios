<?php
function restore($pElement)
{
    //Test l'existance de la variable.
    if (isset($_POST[$pElement]) == true)
    {
        echo 'value="' . $_POST[$pElement] . '"';
    }
}



function getInput($pElementName)
{
    echo '<input id="' , $pElementName , '" type="' , $pElementName , '" name="' , $pElementName , '"';
    restore($pElementName);
    echo '/>';
}

$aCivilite[1] = 'Homme';
$aCivilite[2] = 'Femme';

$j = 1;
while ($j<=31) {
$aJour[$j] = $j;
$j++;
}

$m = 1;
while ($m<=12) {
$aMois[$m] = $m;
$m++;
}

$a = 2014;
while ($a>=1900) {
$aAnnee[$a] = $a;
$a--;
}

?>
