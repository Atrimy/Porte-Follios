<?php
require 'ParamsSession.php';
$test = 0;
require 'params.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>TP2 : Log-In</title>
        <link rel="stylesheet" href="style.css"/>
    </head>
    <body>
        <h1 class="titre">Log-In</h1>
        <form class='form_login' method="post" action="index.php" enctype="multipart/form-data">
            <div class="fond2ndplan">
                <div class="stylediv">
                        <?php
                    #<!-- DEFINITION DU Pseudo --># 
                            echo '<label class="labellogin" for="Pseudo">Pseudo : </label>';
                            getInput('Pseudo');
                            echo '<br />';
                            
                    #<!-- DEFINITION DU MDP --># 
                            echo '<label class="labellogin" for="MDP">Mot de passe : </label>';
                            echo '<input id="MDP" type="password" name="MDP" />';

                    #<!-- TEST ERREUR --># 
                            if (empty($_POST) == false) 
                            {
                                if ($_POST['Pseudo'] == '' | $_POST['MDP'] == '' | $_POST['Pseudo'] != Staff_Pseudo & $_POST['MDP'] != Staff_Password | $_POST['Pseudo'] != Joueur_Pseudo & $_POST['MDP'] != Joueur_motdepasse)
                                {
                                    echo '<p class="error">/!\ Pseudo ou Mot de passe incorect</p>';
                                    $test = 1;
                                }
                            }
                        ?>
                        <br />
                        <input type="submit" value="Log-in"/>
                    </form>
                    <form method="post" action="inscription.php" enctype="multipart/form-data">
                        <input type="submit" value="Sign-in"/>
                    </form>
                    </div>
                </div>
                <?php
                    $dsn            = 'mysql:dbname=ml_server;host=127.0.0.1';
                    $USER_Pseudo    = 'root';
                    $USER_Password  = '';
                    $oDb = new PDO($dsn, $USER_Pseudo, USER_PWD);
                    $oResultat = $oDb -> query('SELECT Joueur_Pseudo,Joueur_motdepasse,Staff_Pseudo,Staff_Password FROM Staff');
                    
                    if (empty($_POST) == false) 
                    {
                        if (($_POST['Pseudo'] == Staff_Pseudo & $_POST['MDP'] == Staff_Password) | ($_POST['Pseudo'] == Joueur_Pseudo & $_POST['MDP'] == Joueur_motdepasse))
                        {
                            $_SESSION['isAuthenticated'] = TRUE;
                            header('location: page1.php');
                            exit;
                        }
                    }
                ?>
            </form>
    </body>
</html>