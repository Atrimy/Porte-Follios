<?php
    require 'ParamsSession.php';
    checkAuthentification();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Page 1</title>
        <link rel="stylesheet" href="style.css"/>
    </head>
    <body>
        <form method="post" action="page2.php" enctype="multipart/form-data">
            <input type="submit" value="Page 2"/>
        </form>
        <form method="post" action="deconnexion.php" enctype="multipart/form-data">
            <input type="submit" value="Deconnexion"/>
        </form>
            <?php
                $dsn        = 'mysql:dbname=ml_server;host=127.0.0.1';
                $USER_Pseudo       = 'root';
                $USER_Password   = '';

                $oDb = new PDO($dsn, $USER_Pseudo, $USER_Password);
            //lancement d'un requête SQL
                $oResultat=$oDb->query('Select * From Zones');
            //compte le nombre de zones
                echo $oResultat->rowCount();
                $oResultat->setFetchMode(PDO::FETCH_OBJ);

            //affiche toutes les zones par ordre alphabétique
                //affiche 1 ligne
                    while ($Zones = $oResultat->fetch())
                    {
                        echo '<p>' , $Zones->Zones_ID , ' -> ' , $Zones->Zone_Libelle , '</p>';
                    }
            ?>
    </body>
</html>
