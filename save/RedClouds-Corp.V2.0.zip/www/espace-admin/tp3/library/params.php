<?php
/**
 * Crée et retourne une instance de PDO (objet de connexion à la base de données)
 * @return \PDO
 */
function getDb()
{
    // Définit les paramètres de la base de données
    $dsn        = 'mysql:dbname=iia;host=127.0.0.1';
    $user_name  = 'root';
    $user_pwd   = '';
    // Crée un nouvel objet PDO (classe qui permet de gérer la base de données)
    $oDb = new PDO($dsn, $user_name, $user_pwd);

    return $oDb;
}