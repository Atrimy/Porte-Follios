<!DOCTYPE html>
<?php
    //require '../library/params.php';
    // Se connecte à la base de donnée
    // /!\ ATTENTION : utiliser PDO et non mysql_connect(), mysql _query()...
    $oDb = My_Db::getDB();
        
//============================================================================
// TRAITEMENT DU FORMULAIRE
//============================================================================
        // Vérifie si le POST n'est pas vide (formulaire envoyé)
        if (empty($_POST)== false)
        {
            //test si le nom de promotion n'est pas vide
            if (empty($_POST['Pro_lib'])== false)
            {
                // INSERT INTO ...
                // Prépare une requète qui attend des paramètres représentés par les ":"
                $oReq = $oDb->prepare('INSERT INTO promotion (Pro_lib) VALUES (:Promotion_lib)');
                // Execute la requète en injectant les paramètres
                $oReq->execute(array(':Promotion_lib' => $_POST['Pro_lib']));
            
            // On peut aussi utiliser l'autre méthode'
            //    $proNom = $oDb -> quote($_POST['Pro_lib']);
            //    $oDb ->query('INSERT INTO promotion(Pro_lib) VALUES ('.$proNom.')')
  
                $OkFormAjout ='La promotion a été ajouté avec succès';
            }
            else
            {
                $errorFormAjout = 'Veuillez saisir un nom de promotion';
            }
        }
        
        $oResultat = My_Entity_Promotion::getAll();
?>

