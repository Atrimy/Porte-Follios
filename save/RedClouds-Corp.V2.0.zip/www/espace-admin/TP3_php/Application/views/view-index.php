<html>
    <head>
        <meta charset="UTF-8">
        <title>TP3 Gestion IIA</title>
        <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
        
        <div>
            <?php
            if (isset($errorFormAjout)== true)
            {
                echo '<p class="error">'.$errorFormAjout. '</p>';
            }
            if (isset($OkFormAjout)== true)
            {
                echo '<p class="succes">'.$OkFormAjout. '</p>';
            }
            ?>
            <form method="post" action="">
                Ajouter une promotion :
                <input type="text" name="Pro_lib" >
                <input type="submit" value="OK">
            </form>
        </div>
        <h1>Liste des promotions</h1>
        <?php
        // Affiche le nombre de résultats retournés (Nombre de promotions)
           echo '<p>Nombre de promotions : ', $oResultat->rowCount(), '</p>';
  
        // Afficher toutes les promotions par ordre alphabétique
           // On récupète un résultat, fetch retourne la première ligne
           while ($oPromotion = $oResultat -> fetch())
           {
               // on récupère le résultat sous forme d'un objet d'après la définition du fetchmode
               echo '<p>';
                    echo '<a href="promotion.php?pro_id=', $oPromotion->Pro_ID , '"> ';
                        echo $oPromotion->Pro_lib;
                    echo '</a>';
               echo '</p>';
           }
           
           /*
           $promotion = $oResultat->fetch();
           var_dump($promotion);
           echo '<p><b>', $promotion['Pro_ID'] , ' > ' , $promotion['Pro_lib'], '</b></p>';
           
           // On récupète un résultat, fetch retourne la deuxième ligne
           $promotion = $oResultat->fetch();
           var_dump($promotion);
           echo '<p><b>', $promotion['Pro_ID'] , ' > ' , $promotion['Pro_lib'], '</b></p>';
           
           // On récupète un résultat, fetch retourne la ligne suivante
           $promotion = $oResultat->fetch();
           var_dump($promotion);
           echo '<p><b>', $promotion['Pro_ID'] , ' > ' , $promotion['Pro_lib'], '</b></p>';
           */
           
        ?>
    </body>
</html>