<?php

/**
 * Se connecte à la base de donnée
 * @return \PDO
 */

function getDB()
{
           $dsn         = 'mysql:dbname=tp3_gestion_iia;host=127.0.0.1';
           $user_name   = 'root';
           $user_pwd    = '';

           $oDb = new PDO($dsn, $user_name, $user_pwd);
           
           return $oDb;
}

?>