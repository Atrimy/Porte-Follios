<?php

session_start();

define('USER_LOGIN', 'Atrimy');
define('USER_SKYPE', 'atrimy');
define('USER_PWD', 'mot');

function checkAuthentification()
{
    if (isset($_SESSION['isAuthenticated']) == FALSE)
    {   // Si non OK, alors redirection vers la home.
        header("location:PageErreurAuthentification.php");
        exit;
    }
}


function checkAuthentificationINDEX()
{
    if (isset($_SESSION['isAuthenticated']) == TRUE)
    {   // Si non OK, alors redirection vers la home.
        header("location:Dejaconnecter.php");
        exit;
    }
}
    
$aCivilite[1] = 'Homme';
$aCivilite[2] = 'Femme';

$j = 1;
while ($j<=31) {
$aJour[$j] = $j;
$j++;
}

$m = 1;
while ($m<=12) {
$aMois[$m] = $m;
$m++;
}

$a = 2014;
while ($a>=1900) {
$aAnnee[$a] = $a;
$a--;
}