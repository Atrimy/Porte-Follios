<?php
//démarre la sesion
require'parametre/ParamsSession.php';
//vide le tableau
$_SESSION = array();
//Détruit la session
session_destroy();
//redirige le visiteur déconecté vers index.php
header('location: index.php');
?>
