<html>
    <?php header ("location: http://webeducation.lyceehautefollis.asso.fr/") ?>
</html>