    	<div id="DivMenu">
            <span id="Connexion">Connexion</span>
	        <span id="Langue">Langue</span>
        	<span id="Monnaie">Monnaie</span>
        </div>