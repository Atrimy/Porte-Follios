        <div id="DivMenu2">
        	<img id="Logo" src="http://127.0.0.1/SiteBts/image/Fond-Connexion.jpg" />
            
            <form>
            	<input id="TexteId" type="text" name="Id" />
                <input id="ButtonId" type="button" name="ButtonId" value="R" />
            </form>
            
            <span id="BOffre">Offre</span>
        </div>
        
		<div id="DivMenu3">
	        <span id="Accueil">Accueil</span>
            <span id="Casting">Casting</span>
            <span id="Acteur">Acteur</span>
        </div>
