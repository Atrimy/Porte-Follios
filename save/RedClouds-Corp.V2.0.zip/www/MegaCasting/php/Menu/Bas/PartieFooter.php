

    <div id="BlocInfo">
        <span id="MIE">Message d'information ou d'erreure</span>
        <form>
            <input id="Email" type="text" name="Email" value="Saisissez votre adresse mail">
        </form>
    </div>

	<div id="BlocBot">

    	<div id="BlocFb">
            <div id="SecondBlocFb">
                    <iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FMegacastingbts&amp;width&amp;height=270&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:290px;" allowTransparency="true">
                    </iframe>
            </div>
    	</div>
    	
        <div id="BlocDonne">
            <div id="Information">
                <span id="info">Information</span>
                <ul id="ul1">
                    <li id="li1">Abonnement</li>
                    <li id="li2">Nouveau Casting</li>
                    <li id="li3">Mellieur Casting</li>
                    <li id="li4">Contactez-nous</li>
                    <li id="li5">Mentions légales</li>
                    <li id="li6">Conditions d'utilisation</li>
                </ul>
            </div>
            
            <div id="Compte">
                <span id="Comp">Mon compte</span>
                <ul id="ul2">
                    <li id="li7">Mes commandes</li>
                    <li id="li8">Mes avoirs</li>
                    <li id="li9">Mes adresses</li>
                    <li id="li10">Mes informations personnelles</li>
                    <li id="li11">Déconnexion</li>
                </ul>
            </div>
        </div>
    
    </div>
