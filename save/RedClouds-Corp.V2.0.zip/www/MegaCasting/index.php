	<?php
		header('Location: ./php/Accueil.php');
		exit();
	?>